<?php

$ball = "kuning";
 //Coba ubah ke "yellow", "blue", "green", "purple", atau warna lain
if ($ball == "red") {
 $redbox = $ball;
	echo "red box : $redbox <br>";
} elseif ($ball == "yellow") {
 $yellowbox = $ball;
	echo "yellow box : $yellowbox <br>";
} elseif ($ball == "blue") {
 $bluebox = $ball;
	echo "blue box : $bluebox <br>";
} elseif ($ball == "green") {
 $greenbox = $ball;
	echo "green box : $greenbox <br>";
} elseif ($ball == "purple") {
 $purplebox = $ball;
	echo "purple box : $purplebox <br>";
} else {
 $colorlessbox = $ball;
	echo "colorless box : $colorlessbox <br>";
}
?> 